Contains job submission scripts, raw data, processed data, 
analysis of processed data, and plots used in publication.

For more detailed information about how directory structure,
see the edd Github repo README.
